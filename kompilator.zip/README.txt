Kod kompilatora - JFTT 2023

Autor: Łukasz Machnik

Dostarczone pliki:
------------------------------------
README.txt
kompilator.lex - analizator leksykalny kodu
kompilator.y - parser, kod zawierający główną logikę kompilatora
Makefile
utils.cpp - plik zawierający definicje kilku funkcji pomocniczych
utils.hpp - plik nagłówkowy zawierający deklaracje kilku funkcji pomocniczych
