#ifndef utils
#define  utils

#include <string>

std::string insertingNumber(std::string r, unsigned long long number);
void printCmd(std::string commandBlock, std::string outputFile);

#endif
